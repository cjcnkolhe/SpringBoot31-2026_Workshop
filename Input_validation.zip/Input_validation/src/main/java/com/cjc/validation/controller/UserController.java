package com.cjc.validation.controller;

import com.cjc.validation.dto.UserRequest;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {

    @PostMapping("/api/users")
    public ResponseEntity<String> createUser(@Valid @RequestBody UserRequest request) {
        // business logic here
        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body("User created successfully");
    }
}
