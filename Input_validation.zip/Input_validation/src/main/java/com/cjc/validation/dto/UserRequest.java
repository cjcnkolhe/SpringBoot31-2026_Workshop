package com.cjc.validation.dto;

import jakarta.validation.constraints.*;
import lombok.Data;

import java.time.LocalDate;

@Data
public class UserRequest {

    /* ---------- BASIC STRING VALIDATIONS ---------- */

    @NotBlank(message = "Name must not be empty")
    @Size(min = 3, max = 30, message = "Name must be between 3 and 30 characters")
    private String name;

    @NotBlank(message = "Username must not be empty")
    @Pattern(
            regexp = "^[A-Za-z0-9._-]{5,20}$",
            message = "Username can contain letters, numbers, dot, underscore and hyphen (5–20 chars)"
    )
    private String username;

    /* ---------- EMAIL VALIDATION ---------- */
    @NotBlank(message = "Email must not be empty")
    @Email(message = "Email must be valid")
    private String email;

    /* ---------- MOBILE NUMBER VALIDATION ---------- */
    /* India-specific example */
    @NotBlank(message = "Mobile number must not be empty")
    @Pattern(
            regexp = "^[6-9]\\d{9}$",
            message = "Mobile number must be a valid 10-digit Indian number"
    )
    private String mobileNumber;

    /* ---------- NUMBER VALIDATIONS ---------- */

    @NotNull(message = "Age must not be null")
    @Min(value = 18, message = "Age must be at least 18")
    @Max(value = 60, message = "Age must not exceed 60")
    private Integer age;

    /* ---------- DATE VALIDATIONS ---------- */

    @NotNull(message = "Date of birth must not be null")
    @Past(message = "Date of birth must be in the past")
    // format -> yyyy-MM-dd
    private LocalDate dateOfBirth;

//    @Pattern(
//            regexp = "^(19|20)\\d\\d-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d|3[01])$",
//            message = "DOB must be in yyyy-MM-dd format"
//    )
//    private String dateOfBirth;

    /* ---------- BOOLEAN VALIDATION ---------- */

    @AssertTrue(message = "Terms and conditions must be accepted")
    private Boolean termsAccepted;

}

