package com.cjc.properties.controller;

import com.cjc.properties.config.CoffeeProperties;
import lombok.AllArgsConstructor;
import lombok.Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/coffee")
@Data
public class CoffeeController {

    @Value("${coffee.enabled}")
    private boolean isCoffeeEnable;

    @Value("${coffee.teams}")
    private List<String> teams;

    @Value("${coffee.tea:redLabel}")
    private String tea;

    @Value("${test.value}")
    private String testValue;

    @Autowired
    private Environment env;

    private  final CoffeeProperties coffeeProperties;

    public CoffeeController(CoffeeProperties coffeeProperties) {
        this.coffeeProperties = coffeeProperties;
    }


    @GetMapping("/props")
    public CoffeeProperties getAllProps() {
        return coffeeProperties;
    }

    @GetMapping("/value")
    public boolean getValue() {
        return isCoffeeEnable;
    }

    @GetMapping("/teams")
    public List<String> getTeams() {
        return coffeeProperties.getTeams();
    }

    @GetMapping("/env")
    public String env() {
        return env.getProperty("coffee.teams");
    }

    @GetMapping("/default")
    public String defaultValue() {
        return tea;
    }

    @GetMapping("/test")
    public String testValue() {
        return testValue;
    }
}
