package com.cjc.properties.config;

import lombok.Data;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Component
@ConfigurationProperties(prefix = "coffee")
@Data
public class CoffeeProperties {
    private boolean enabled;
    // list of primitives
    private List<String> teams;
    // map of primitives
    private Map<String, Integer> dailyLimit;
    private Map<String, Boolean> withdrawalMode;
}

