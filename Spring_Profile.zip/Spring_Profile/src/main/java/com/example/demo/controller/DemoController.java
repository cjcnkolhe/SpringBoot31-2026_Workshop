package com.example.demo.controller;


import com.example.demo.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DemoController {

    @Value("${db.password}")
    private String password;

    @Autowired
    private PaymentService paymentService;

    @GetMapping("/")
    public String getString() {
        System.out.println(password);
        return password;
    }

    @GetMapping("/payment")
    public String processPayment() {
        return paymentService.payment();
    }

}
