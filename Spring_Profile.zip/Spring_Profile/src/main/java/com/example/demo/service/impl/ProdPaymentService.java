package com.example.demo.service.impl;

import com.example.demo.service.PaymentService;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

@Service
@Profile("prod")
public class ProdPaymentService implements PaymentService {
    @Override
    public String payment() {
        return "Processing actual payment from PROD profile";
    }
}
