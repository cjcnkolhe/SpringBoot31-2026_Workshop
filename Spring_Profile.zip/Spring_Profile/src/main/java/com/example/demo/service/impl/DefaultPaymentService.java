package com.example.demo.service.impl;

import com.example.demo.service.PaymentService;
import org.springframework.context.annotation.Profile;
import org.springframework.stereotype.Service;

@Service
@Profile("!prod")
public class DefaultPaymentService implements PaymentService {
    @Override
    public String payment() {
        return "Processing dummy payment from non prod profile";
    }
}
