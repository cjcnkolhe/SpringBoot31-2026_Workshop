package com.example.demo.service;

public interface PaymentService {

    public String payment();
}
