package com.spring.scope.scope.controller;

import com.spring.scope.scope.bean.Laptop;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class LaptopControlle {

    @Autowired
    Laptop laptop;

    @GetMapping("/laptop")
    public String laptop(){
        return laptop.getName();
    }
}
