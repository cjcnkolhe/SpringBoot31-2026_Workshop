package com.spring.scope.scope.bean;

import lombok.Data;
import org.springframework.stereotype.Component;
import org.springframework.web.context.annotation.RequestScope;
import org.springframework.web.context.annotation.SessionScope;

@Component
@Data
//@RequestScope
@SessionScope
public class Laptop {

    private String name="MacBook Pro";

    public Laptop(){
        System.out.println("Laptop Constructor");
    }

}
